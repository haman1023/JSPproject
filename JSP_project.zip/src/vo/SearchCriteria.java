package vo;

public class SearchCriteria extends Criteria{
	private String searchValue;
	
	public SearchCriteria(int page, int perPageNum, String searchValue) {
		super(page,perPageNum);
		this.searchValue = searchValue;
	}
	
	public String getSearchValue() {
		return searchValue;
	}

	public void setSearchValue(String searchValue) {
		this.searchValue = searchValue;
	}

	@Override
	public String toString() {
		return "SearchCriteria [searchValue=" + searchValue + "]";
	}


	
}