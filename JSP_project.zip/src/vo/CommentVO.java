package vo;

import java.util.Date;

public class CommentVO {

	private int com_num;
	private String com_writer_id;
	private String com_writer_nick;
	private int com_content_num;
	private String com_content;
	private Date com_date;
	private String com_writer_file;
	
	public CommentVO() {}
	
	public CommentVO(String com_writer_id, String com_writer_nick, int com_content_num, String com_content,
			String com_writer_file) {
		this.com_writer_id = com_writer_id;
		this.com_writer_nick = com_writer_nick;
		this.com_content_num = com_content_num;
		this.com_content = com_content;
		this.com_writer_file = com_writer_file;
	}

	public CommentVO(int com_num, String com_writer_id, String com_writer_nick, int com_content_num, String com_content,
			Date com_date, String com_writer_file) {
		this.com_num = com_num;
		this.com_writer_id = com_writer_id;
		this.com_writer_nick = com_writer_nick;
		this.com_content_num = com_content_num;
		this.com_content = com_content;
		this.com_date = com_date;
		this.com_writer_file = com_writer_file;
	}

	public int getCom_num() {
		return com_num;
	}

	public void setCom_num(int com_num) {
		this.com_num = com_num;
	}

	public String getCom_writer_id() {
		return com_writer_id;
	}

	public void setCom_writer_id(String com_writer_id) {
		this.com_writer_id = com_writer_id;
	}

	public String getCom_writer_nick() {
		return com_writer_nick;
	}

	public void setCom_writer_nick(String com_writer_nick) {
		this.com_writer_nick = com_writer_nick;
	}

	public int getCom_content_num() {
		return com_content_num;
	}

	public void setCom_content_num(int com_content_num) {
		this.com_content_num = com_content_num;
	}

	public String getCom_content() {
		return com_content;
	}

	public void setCom_content(String com_content) {
		this.com_content = com_content;
	}
	
	public Date getCom_date() {
		return com_date;
	}

	public void setCom_date(Date com_date) {
		this.com_date = com_date;
	}
	
	public String getCom_writer_file() {
		return com_writer_file;
	}

	public void setCom_writer_file(String com_writer_file) {
		this.com_writer_file = com_writer_file;
	}

	@Override
	public String toString() {
		return "CommentVO [com_num=" + com_num + ", com_writer_id=" + com_writer_id + ", com_writer_nick="
				+ com_writer_nick + ", com_content_num=" + com_content_num + ", com_content=" + com_content
				+ ", com_date=" + com_date + ", com_writer_file=" + com_writer_file + "]";
	}
}
