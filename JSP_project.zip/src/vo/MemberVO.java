package vo;

import java.util.Date;

public class MemberVO {
	private String m_id;
	private String m_pass;
	private String m_nick;
	private String m_email;
	private String m_birth;
	private String m_gender;
	private Date m_date;
	private String m_file;
	private String m_comment;
	
	public MemberVO() {}
	
	public MemberVO(String m_id, String m_pass, String m_nick, String m_email, String m_birth, String m_gender) {
		this.m_id = m_id;
		this.m_pass = m_pass;
		this.m_nick = m_nick;
		this.m_email = m_email;
		this.m_birth = m_birth;
		this.m_gender = m_gender;
	}

	public MemberVO(String m_id, String m_pass, String m_nick, String m_email, String m_birth, String m_gender,
			Date m_date, String m_file, String m_comment) {
		this.m_id = m_id;
		this.m_pass = m_pass;
		this.m_nick = m_nick;
		this.m_email = m_email;
		this.m_birth = m_birth;
		this.m_gender = m_gender;
		this.m_date = m_date;
		this.m_file = m_file;
		this.m_comment = m_comment;
	}

	public String getM_id() {
		return m_id;
	}

	public void setM_id(String m_id) {
		this.m_id = m_id;
	}

	public String getM_pass() {
		return m_pass;
	}

	public void setM_pass(String m_pass) {
		this.m_pass = m_pass;
	}

	public String getM_nick() {
		return m_nick;
	}

	public void setM_nick(String m_nick) {
		this.m_nick = m_nick;
	}

	public String getM_email() {
		return m_email;
	}

	public void setM_email(String m_email) {
		this.m_email = m_email;
	}

	public String getM_birth() {
		return m_birth;
	}

	public void setM_birth(String m_birth) {
		this.m_birth = m_birth;
	}

	public String getM_gender() {
		return m_gender;
	}

	public void setM_gender(String m_gender) {
		this.m_gender = m_gender;
	}

	public Date getM_date() {
		return m_date;
	}

	public void setM_date(Date m_date) {
		this.m_date = m_date;
	}

	public String getM_file() {
		return m_file;
	}

	public void setM_file(String m_file) {
		this.m_file = m_file;
	}

	public String getM_comment() {
		return m_comment;
	}

	public void setM_comment(String m_comment) {
		this.m_comment = m_comment;
	}

	@Override
	public String toString() {
		return "MemberVO [m_id=" + m_id + ", m_pass=" + m_pass + ", m_nick=" + m_nick + ", m_email=" + m_email
				+ ", m_birth=" + m_birth + ", m_gender=" + m_gender + ", m_date=" + m_date + ", m_file=" + m_file
				+ ", m_comment=" + m_comment + "]";
	}
}
