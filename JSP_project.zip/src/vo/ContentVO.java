package vo;

import java.util.Date;

public class ContentVO {

	private int c_num;
	private String c_writer_id;
	private String c_nick;
	private String c_content;
	private String c_img;
	private String c_writer_file;
	private Date c_date;
	
	public ContentVO() {}

	public ContentVO(String c_writer_id, String c_nick, String c_content, String c_img, String c_writer_file) {
		this.c_writer_id = c_writer_id;
		this.c_nick = c_nick;
		this.c_content = c_content;
		this.c_img = c_img;
		this.c_writer_file = c_writer_file;
	}

	public ContentVO(int c_num, String c_writer_id, String c_nick, String c_content, String c_img, String c_writer_file,
			Date c_date) {
		this.c_num = c_num;
		this.c_writer_id = c_writer_id;
		this.c_nick = c_nick;
		this.c_content = c_content;
		this.c_img = c_img;
		this.c_writer_file = c_writer_file;
		this.c_date = c_date;
	}

	public int getC_num() {
		return c_num;
	}

	public void setC_num(int c_num) {
		this.c_num = c_num;
	}

	public String getC_writer_id() {
		return c_writer_id;
	}

	public void setC_writer_id(String c_writer_id) {
		this.c_writer_id = c_writer_id;
	}

	public String getC_nick() {
		return c_nick;
	}

	public void setC_nick(String c_nick) {
		this.c_nick = c_nick;
	}

	public String getC_content() {
		return c_content;
	}

	public void setC_content(String c_content) {
		this.c_content = c_content;
	}

	public String getC_img() {
		return c_img;
	}

	public void setC_img(String c_img) {
		this.c_img = c_img;
	} 
	
	public String getC_writer_file() {
		return c_writer_file;
	}

	public void setC_writer_file(String c_writer_file) {
		this.c_writer_file = c_writer_file;
	}

	public Date getC_date() {
		return c_date;
	}

	public void setC_date(Date c_date) {
		this.c_date = c_date;
	}

	@Override
	public String toString() {
		return "ContentVO [c_num=" + c_num + ", c_writer_id=" + c_writer_id + ", c_nick=" + c_nick + ", c_content="
				+ c_content + ", c_img=" + c_img + ", c_writer_file=" + c_writer_file + ", c_date=" + c_date + "]";
	}
}
