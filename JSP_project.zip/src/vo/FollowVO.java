package vo;

public class FollowVO {

	private String following_id;
	private String follower_id;
	
	public FollowVO() {}
	
	public FollowVO(String following_id, String follower_id) {
		this.following_id = following_id;
		this.follower_id = follower_id;
	}

	public String getFollowing_id() {
		return following_id;
	}

	public void setFollowing_id(String following_id) {
		this.following_id = following_id;
	}

	public String getFollower_id() {
		return follower_id;
	}

	public void setFollower_id(String follower_id) {
		this.follower_id = follower_id;
	}

	@Override
	public String toString() {
		return "FollowVO [following_id=" + following_id + ", follower_id=" + follower_id + "]";
	}
}
