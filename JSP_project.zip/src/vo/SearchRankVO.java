package vo;

public class SearchRankVO {
	
	private String sc_content;
	private int searchCount;

	public SearchRankVO(String sc_content, int searchCount) {
		this.sc_content = sc_content;
		this.searchCount = searchCount;
	}
	
	public String getSc_content() {
		return sc_content;
	}
	public void setSc_content(String sc_content) {
		this.sc_content = sc_content;
	}
	public int getSearchCount() {
		return searchCount;
	}
	public void setSearchCount(int searchCount) {
		this.searchCount = searchCount;
	}
	@Override
	public String toString() {
		return "SearchRankVO [sc_content=" + sc_content + ", searchCount=" + searchCount + "]";
	}
	
	

}
