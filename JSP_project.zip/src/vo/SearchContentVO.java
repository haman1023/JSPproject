package vo;

import java.util.Date;

public class SearchContentVO {

	private String sc_content;
	private String sc_birth;
	private String sc_gender;
	private Date sc_date;
	private String sc_id;
	
	public SearchContentVO() {}
	
	public SearchContentVO(String sc_content, String sc_birth, String sc_gender, String sc_id) {
		this.sc_content = sc_content;
		this.sc_birth = sc_birth;
		this.sc_gender = sc_gender;
		this.sc_id = sc_id;
	}

	public SearchContentVO(String sc_content, String sc_birth, String sc_gender, Date sc_date, String sc_id) {
		this.sc_content = sc_content;
		this.sc_birth = sc_birth;
		this.sc_gender = sc_gender;
		this.sc_date = sc_date;
		this.sc_id = sc_id;
	}
	
	public String getSc_content() {
		return sc_content;
	}
	public void setSc_content(String sc_content) {
		this.sc_content = sc_content;
	}
	public String getSc_birth() {
		return sc_birth;
	}
	public void setSc_birth(String sc_birth) {
		this.sc_birth = sc_birth;
	}
	public String getSc_gender() {
		return sc_gender;
	}
	public void setSc_gender(String sc_gender) {
		this.sc_gender = sc_gender;
	}
	public Date getSc_date() {
		return sc_date;
	}
	public void setSc_date(Date sc_date) {
		this.sc_date = sc_date;
	}
	
	public String getSc_id() {
		return sc_id;
	}

	public void setSc_id(String sc_id) {
		this.sc_id = sc_id;
	}

	@Override
	public String toString() {
		return "SearchContentVO [sc_content=" + sc_content + ", sc_birth=" + sc_birth + ", sc_gender=" + sc_gender
				+ ", sc_date=" + sc_date + ", sc_id=" + sc_id + "]";
	}
}
