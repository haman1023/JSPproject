package vo;

public class LikeContentVO {
	
	private int lc_num;
	private String lc_id;
	private String lc_file;
	
	public LikeContentVO() {}
	
	public LikeContentVO(String lc_id, String lc_file) {
		this.lc_id = lc_id;
		this.lc_file = lc_file;
	}

	public LikeContentVO(int lc_num, String lc_id, String lc_file) {
		this.lc_num = lc_num;
		this.lc_id = lc_id;
		this.lc_file = lc_file;
	}

	public int getLc_num() {
		return lc_num;
	}

	public void setLc_num(int lc_num) {
		this.lc_num = lc_num;
	}

	public String getLc_id() {
		return lc_id;
	}

	public void setLc_id(String lc_id) {
		this.lc_id = lc_id;
	}
	
	public String getLc_file() {
		return lc_file;
	}

	public void setLc_file(String lc_file) {
		this.lc_file = lc_file;
	}

	@Override
	public String toString() {
		return "LikeContentVO [lc_num=" + lc_num + ", lc_id=" + lc_id + ", lc_file=" + lc_file + "]";
	}
}
