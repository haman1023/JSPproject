package vo;

public class DMUserList {
	
	private String dm_user_id;
	private String dm_user_nick;
	private String dm_user_file;
	private String dm_message;
	
	public DMUserList() {}

	public String getDm_user_id() {
		return dm_user_id;
	}

	public void setDm_user_id(String dm_user_id) {
		this.dm_user_id = dm_user_id;
	}

	public String getDm_user_nick() {
		return dm_user_nick;
	}

	public void setDm_user_nick(String dm_user_nick) {
		this.dm_user_nick = dm_user_nick;
	}

	public String getDm_user_file() {
		return dm_user_file;
	}

	public void setDm_user_file(String dm_user_file) {
		this.dm_user_file = dm_user_file;
	}

	public String getDm_message() {
		return dm_message;
	}

	public void setDm_message(String dm_message) {
		this.dm_message = dm_message;
	}

	@Override
	public String toString() {
		return "DMUserList [dm_user_id=" + dm_user_id + ", dm_user_nick=" + dm_user_nick + ", dm_user_file="
				+ dm_user_file + ", dm_message=" + dm_message + "]";
	}
}
