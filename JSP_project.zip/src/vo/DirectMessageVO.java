package vo;

import java.util.Date;

public class DirectMessageVO {
	
	private String dm_send_id;
	private String dm_receive_id;
	private String dm_content;
	private Date dm_date;
	
	public DirectMessageVO() {}
	
	public DirectMessageVO(String dm_send_id, String dm_receive_id, String dm_content) {
		this.dm_send_id = dm_send_id;
		this.dm_receive_id = dm_receive_id;
		this.dm_content = dm_content;
	}
	
	public DirectMessageVO(String dm_send_id, String dm_receive_id, String dm_content, Date dm_date) {
		this.dm_send_id = dm_send_id;
		this.dm_receive_id = dm_receive_id;
		this.dm_content = dm_content;
		this.dm_date = dm_date;
	}

	public String getDm_send_id() {
		return dm_send_id;
	}

	public void setDm_send_id(String dm_send_id) {
		this.dm_send_id = dm_send_id;
	}

	public String getDm_receive_id() {
		return dm_receive_id;
	}

	public void setDm_receive_id(String dm_receive_id) {
		this.dm_receive_id = dm_receive_id;
	}

	public String getDm_content() {
		return dm_content;
	}

	public void setDm_content(String dm_content) {
		this.dm_content = dm_content;
	}

	public Date getDm_date() {
		return dm_date;
	}

	public void setDm_date(Date dm_date) {
		this.dm_date = dm_date;
	}

	@Override
	public String toString() {
		return "DirectMessageVO [dm_send_id=" + dm_send_id + ", dm_receive_id=" + dm_receive_id + ", dm_content="
				+ dm_content + ", dm_date=" + dm_date + "]";
	}
}
