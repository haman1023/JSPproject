package service;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

public interface DirectMessageService {

	/**
	 * DM을 했던 유저 리스트
	 * @param request - 회원 아이디
	 */
	void getDMList(HttpServletRequest request);

	/**
	 * DM 메세지 불러오기
	 * @param request - 회원 아이디, 대상 아이디
	 * @return - DM 목록
	 */
	HashMap<String, Object> getDirectMessage(HttpServletRequest request);
	
	/**
	 * DM 메세지 보내기
	 * @param request - 대상 아이디, message
	 * @return - 성공 여부
	 */
	boolean sendDirectMessage(HttpServletRequest request);

}
