package service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface MemberService {
	
	// 회원 가입 처리
	boolean memberJoin(HttpServletRequest request, HttpServletResponse response);
	/* 
	 * 로그인 처리
	 * @result true - 로그인 성공
	 * @result false - 로그인 실패
	 */
	boolean memberLogin(HttpServletRequest request, HttpServletResponse response);
	
	/**
	 * attr - 회원정보 수정
	 * @param request - 수정 정보
	 * @param response - 응답 정보
	 */
	boolean memberUpdate(HttpServletRequest request);
	
	/**
	 * 회원탈퇴 요청
	 * @param request - 재입력 비밀번호
	 * @param response - 응답 정보
	 */
	void withdrawSubmit(HttpServletRequest request, HttpServletResponse response);
	
	/**
	 * 로그아웃 처리
	 * Session Cookie 정보 초기화
	 */
	void logOut(HttpServletRequest request, HttpServletResponse response);
	
	/**
	 * 비밀번호 변경 사용자 정보 확인 / 메일 발송
	 * @param request - member m_email
	 * @param response - 요청 정보 처리에 따른 화면 전환
	 */
	void findIdSubmit(HttpServletRequest request, HttpServletResponse response);
	
	/**
	 * 비밀번호 변경 사용자 정보 확인 / 메일 발송
	 * @param request - member m_id , member m_email
	 * @param response - 요청 정보 처리에 따른 화면 전환
	 */
	void findPassSubmit(HttpServletRequest request, HttpServletResponse response);

	/**
	 * 비밀번호 변경 요청 정보 확인
	 * @param request - m_email , code
	 * @param response - 인증
	 */
	void checkPassCode(HttpServletRequest request, HttpServletResponse response);
	void changePassCode(HttpServletRequest request, HttpServletResponse response);
	
	/**
	 * 개인 정보 페이지
	 * @param request - 조회된 아이디
	 */
	void memberInfo(HttpServletRequest request);
}