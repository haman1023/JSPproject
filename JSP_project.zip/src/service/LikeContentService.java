package service;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

public interface LikeContentService {

	/**
	 * 상세보기에서 필요한 좋아요 정보를 요청
	 * @param request - 게시물 번호
	 * @return 좋아요한 숫자, 좋아요 한 사람 리스트
	 */
	HashMap<String, Object> getLike(HttpServletRequest request);
	
	/**
	 * 상세보기에서 좋아요 클릭
	 * @param request - 게시물 번호, 좋아요 누른 사용자 아이디
	 */
	void clickLike(HttpServletRequest request);

}
