package service;


import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import vo.MemberVO;


public interface ListService {

	// 게시글 목록
	HashMap<String, Object> contentlist(HttpServletRequest request);

	// 검색 게시물 리스트
	HashMap<String, Object> search(HttpServletRequest request);

	//	검색중 닉 리스트
	ArrayList<MemberVO> getSearchNick(HttpServletRequest request);
}
