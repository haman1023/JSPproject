package service;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import dao.MemberDAO;
import dao.MemberDAOImpl;
import util.NaverAuthenticator;
import vo.ContentVO;
//import util.PageInfo;
import vo.MemberVO;

public class MemberServiceImpl implements MemberService{
	
	MemberDAO dao = new MemberDAOImpl();

	// 회원가입
	@Override
	public boolean memberJoin(HttpServletRequest request
			, HttpServletResponse response) {
		
		String m_id =request.getParameter("m_id");
		String m_pass =request.getParameter("m_pass");
		String m_nick =request.getParameter("m_nick");
		String m_email =request.getParameter("m_email");
		String m_birth =request.getParameter("m_birth");
		String m_gender =request.getParameter("m_gender");
		 
		String[] birth = m_birth.split("-");
		m_birth = "";
		for(String b : birth) {
			m_birth += b;
		}
		MemberVO member = new MemberVO(m_id,m_pass,m_nick,m_email,m_birth,m_gender);
		System.out.println(member);
		
		return dao.memberJoin(member);
	}

	// 로그인
	@Override
	public boolean memberLogin(HttpServletRequest request, HttpServletResponse response) {
		
		boolean isLogin = false;
		
		String m_id = request.getParameter("m_id");
		String m_pass = request.getParameter("m_pass");
		
		System.out.println("m_id : " + m_id);
		System.out.println("m_pass : " + m_pass);
		
		MemberVO member = dao.memberLogin(m_id,m_pass);
		
		if(member != null) {
			System.out.println("로그인 되었습니다.");
			HttpSession session = request.getSession();
			session.setAttribute("loginMember", member);
			isLogin = true;
		}else {
			System.out.println("다시 시도해 주세요.");
		}
		return isLogin;
	}
	
	// 로그아웃 처리
	// session 
	public void logOut(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		session.invalidate();
		System.out.println("session 초기화");
			
	}
	
	// 회원 탈퇴
	@Override
	public void withdrawSubmit(HttpServletRequest request, HttpServletResponse response) {
		String m_pass = request.getParameter("m_pass");
		System.out.println("m_pass : " + m_pass);
		
		MemberVO member = (MemberVO)request.getSession().getAttribute("loginMember");
		
		response.setContentType("text/html;charset=utf-8");
		
		try {
			PrintWriter writer = response.getWriter();
			writer.print("<script>");
			if(member != null && m_pass.equals(member.getM_pass())) {
				dao.deleteMember(member.getM_id());
				// Session 정보 삭제
				logOut(request,response);
				
				writer.print("alert('회원탈퇴 완료');");
				writer.print("location.href='index.jsp';");
			}else {
				// 회원 정보 불일치 회원 탈퇴 실패
				writer.print("alert('회원탈퇴 실패');");
				writer.print("history.go(-1);");
			}
			writer.print("</script>");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	

	
	// 아이디 찾기 메일발송 요청
	@SuppressWarnings("unused")
	@Override
	public void findIdSubmit(HttpServletRequest request, HttpServletResponse response) {
		String m_email = request.getParameter("m_email");
		
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = null;
			
		try {
			out = response.getWriter();
				
			String m_id = dao.checkMember(m_email);
			
			System.out.println("m_id : " + m_id + ", m_email : " + m_email);
				
			// 메일 발송
			NaverAuthenticator auth = new NaverAuthenticator();
			Session session
			= Session.getDefaultInstance(auth.getProperties(),auth);
				
			MimeMessage msg = new MimeMessage(session);
			msg.setSentDate(new Date());
			msg.setHeader("Content-Type", "text/html;charset=utf-8");
			msg.setRecipient(
					Message.RecipientType.TO, 
					new InternetAddress(m_email)
			);
			msg.setFrom(new InternetAddress("haman1023@naver.com","MASTER"));
			msg.setSubject("FIND ID !!","UTF-8");
			StringBuilder mail = new StringBuilder();
			mail.append("<h1>@@@ 회원님의 아이디는 "+m_id+" 입니다.</h1>");
				
			String content = new String(mail);
			msg.setContent(content,"text/html;charset=utf-8");
				
			Transport.send(msg);
				
			out.print("<script>alert('이메일 발송 완료! 메일을 확인해주세요');");
			out.print("location.href='index.jsp';</script>");
				
		} catch (Exception e) {
			e.printStackTrace();
			out.print("<script>alert('서비스에 문제가 있습니다. 다시 이용해 주세요!');");
			out.print("location.href='login.kk';</script>");
		}
	}
	// 비밀번호 찾기 메일발송 요청
	@Override
	public void findPassSubmit(HttpServletRequest request, HttpServletResponse response) {
		
		System.out.println("service 메일 발송 요청");
		
		String m_id = request.getParameter("m_id");
		String m_email = request.getParameter("m_email");
		
		System.out.println("m_id : " +m_id+ ", m_email : "+m_email);
		
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = null;
		
		String errorMsg = null;
		
		try {
			out = response.getWriter();
			
			boolean isCheck = dao.checkMember(m_id, m_email);
			
			if(!isCheck) {
				System.out.println("일치하는 정보가 없음");
				errorMsg = "일치하는 정보가 없음";
				throw new NullPointerException(errorMsg);
			}
			
			
			StringBuilder sb = new StringBuilder();
			
			for(int i=0; i<5; i++) {
				// 0 ~ 9
				int random = (int)(Math.random()*10);
				sb.append(random);
			}
			
			String code = sb.toString();
			System.out.println("code : " + code);
			dao.addPassCode(m_email,code);
			
			// 메일 발송
			NaverAuthenticator auth = new NaverAuthenticator();
			Session session
			= Session.getDefaultInstance(auth.getProperties(),auth);
			
			MimeMessage msg = new MimeMessage(session);
			msg.setSentDate(new Date());
			msg.setHeader("Content-Type", "text/html;charset=utf-8");
			msg.setRecipient(
					Message.RecipientType.TO, 
					new InternetAddress(m_email)// 이메일 값이여야 메일이 보내짐
			);
			msg.setFrom(new InternetAddress("haman1023@naver.com","MASTER"));
			msg.setSubject("FIND PASS !!","UTF-8");
			StringBuilder mail = new StringBuilder();
			mail.append("<!DOCType html>");
			mail.append("<html>");
			mail.append("<head>");
			mail.append("<meta charset='utf-8'>");
			mail.append("<title>비밀번호 찾기</title>");
			mail.append("<script>");
			mail.append("function submitPass(){window.open('','w')}");
			mail.append("</script>");
			mail.append("</head>");
			mail.append("<body>");
			mail.append("<h1>SNS 사이트  비밀번호 찾기  이메일 인증</h1>");
			mail.append("<form action='http://192.168.1.29:8080"+request.getContextPath()
			            +"/passAccept.kk' method='post' onsubmit='submitPass()' target='w'>");
			mail.append("<input type='hidden' name='m_email' value='"+m_email+"'/>");
			mail.append("<input type='hidden' name='code' value='"+code+"'/>");
			mail.append("<input type='submit' value='이메일 인증 하기'/>");
			mail.append("</form>");
			mail.append("</body>");
			mail.append("</html>");
			
			String content = new String(mail);
			msg.setContent(content,"text/html;charset=utf-8");
			
			Transport.send(msg);
			
			out.print("<script>alert('이메일 발송 완료! 메일을 확인해주세요');");
			out.print("location.href='index.jsp';</script>");
			
		} catch (Exception e) {
			e.printStackTrace();
			out.print("<script>alert("+e.getMessage()+");");
			out.print("location.href='login.kk';</script>");
		}
	}	
	
	@Override
	public void checkPassCode(HttpServletRequest request, HttpServletResponse response) {
		
		System.out.println("패스 코드 비교 호출");
		
		String m_email = request.getParameter("m_email");
		String code = request.getParameter("code");
		//??????
		System.out.println("m_email : " + m_email + ", code : " + code);
		
		boolean isCheck = dao.checkPassCode(m_email,code);
		System.out.println("isCheck : " + isCheck);
		try {
			if(isCheck) {
				// 새비밀번호 작성 창
				System.out.println("일치");
				request.setAttribute("m_email", m_email);
				request.setAttribute("code", code);
				request.getRequestDispatcher("/member/changePass.jsp")
				.forward(request, response);
			}else {
					PrintWriter out = response.getWriter();
					response.setContentType("text/html;charset=utf-8");
					//PrintWriter out = response.getWriter();
					out.print("<script>");
					out.print("alert('잘못된 요청입니다.');");
					out.print("location.href='login.kk';");
					out.print("</script>");
				
			}
		} catch (Exception e) {}
	}
	
	public void changePassCode(HttpServletRequest request, HttpServletResponse response) {
		String m_email = request.getParameter("m_email");
		String code = request.getParameter("code");
		String m_pass = request.getParameter("m_pass");
		
		System.out.println("m_email : " + m_email);
		System.out.println("code : " + code);
		System.out.println("m_pass : " + m_pass);
		
		boolean isCheck = dao.checkPassCode(m_email, code);
		
		try {
			
			response.setContentType("text/html;charset=utf-8");
			PrintWriter out = response.getWriter();
			
			out.print("<script>");
			if(isCheck) {
				// 비밀번호 변경
				dao.changePass(m_email,m_pass);
				out.print("alert('변경 요청 처리 완료');");
			}else {
				// 비정상적인 접근
				out.print("alert('올바른 접근이 아닙니다.');");
			}
			out.print("location.href='login.kk';");
			out.print("</script>");
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void memberInfo(HttpServletRequest request) {
		String m_id = request.getParameter("m_id");
		request.setAttribute("memberInfo",dao.getMemberById(m_id));
	}

	@Override
	public boolean memberUpdate(HttpServletRequest request) {
		
		String saveDir = "/upload";
		MemberVO member = null;
		boolean isSuccess = false;

		try {
			String realPath = request.getServletContext().getRealPath(saveDir);
			
			MultipartRequest multi = 
					new MultipartRequest(request, realPath, 1024*1024*5, "utf-8", new DefaultFileRenamePolicy());
			
			String m_id = multi.getParameter("m_id");
			String m_nick = multi.getParameter("m_nick");
			String m_comment = multi.getParameter("m_comment");
			String file = (String)multi.getFileNames().nextElement();
			String m_file = multi.getFilesystemName(file);
			
			if(!identification(m_id, request.getSession())) return false;
			
			member = new MemberVO();
			member.setM_id(m_id);
			member.setM_nick(m_nick);
			member.setM_comment(m_comment);
			
			if(m_file == null || m_file.equals(dao.getMemberFile(m_id))) {
				m_file = dao.getMemberFile(m_id);
			}
			member.setM_file(m_file);
			
			isSuccess = dao.memberUpdate(member);
			
			if(isSuccess) {
				MemberVO updateMember = dao.getMemberById(m_id);
				request.getSession().setAttribute("loginMember", updateMember);
				request.setAttribute("m_id", m_id);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isSuccess;
	}

	//	본인 확인 메소드
	private boolean identification(String m_id, HttpSession session) {
		MemberVO loginMember = (MemberVO)session.getAttribute("loginMember");
		
		if(m_id.equals(loginMember.getM_id())) {
			return true;
		}
		return false;
	}
}