package service;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.JsonElement;

public interface ContentService {

	/**
	 * 글 작성
	 * @param request - 글내용(아이디, 닉네임, 글내용, 사진)
	 * @return 작성 성공 여부
	 */
	boolean writeContent(HttpServletRequest request);

	/**
	 * 글 상세보기
	 * @param request - 글번호
	 */
	void getContent(HttpServletRequest request);

	/**
	 * 글 삭제하기
	 * @param request - 글번호
	 * @return 삭제 성공 여부
	 */
	boolean deleteContent(HttpServletRequest request);

	/**
	 * 그림파일 다운로드
	 * @param request - 파일 정보
	 * @param response 
	 */
	void imgDown(HttpServletRequest request, HttpServletResponse response);

	/**
	 * 회원 정보 게시물에서 회원이 쓴 글 리스트 불러오기
	 * @param request - 회원 아이디
	 * @return - 회원이 쓴 게시글 리스트
	 */
	HashMap<String, Object> getWritingList(HttpServletRequest request);

	/**
	 * 회원 정보 게시물에서 회원이 좋아요 누른 리스트 불러오기
	 * @param request - 회원 아이디
	 * @return - 회원이 좋아요 누른 게시글 리스트
	 */
	HashMap<String, Object> getLikeContentList(HttpServletRequest request);

}
