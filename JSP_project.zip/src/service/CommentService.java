package service;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

public interface CommentService {

	/**
	 * 댓글 작성
	 * @param request - 댓글 내용(작성자 아이디, 작성자 닉네임, 작성내용, 작성한 글 번호)
	 * @return 성공 여부
	 */
	boolean insertComment(HttpServletRequest request);

	/**
	 * 댓글 리스트 불러오기
	 * @param request - 페이지
	 * @return 페이징 처리된 댓글 리스트, 페이지 메이커
	 */
	HashMap<String, Object> getCommentList(HttpServletRequest request);

	/**
	 * 댓글 삭제
	 * @param request - 댓글 번호, 댓글 작성자
	 * @return 성공 여부
	 */
	boolean deleteComment(HttpServletRequest request);

}
