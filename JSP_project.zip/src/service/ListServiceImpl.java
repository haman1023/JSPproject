package service;

import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import dao.ListDAO;
import dao.ListDAOImpl;
import dao.SearchDAO;
import dao.SearchDAOImpl;
import vo.ContentVO;
import vo.MemberVO;
import vo.PageMaker;
import vo.SearchContentVO;
import vo.SearchCriteria;
import vo.SearchRankVO;

public class ListServiceImpl implements ListService{
	
	ListDAO dao = new ListDAOImpl();
	SearchDAO searchDAO = new SearchDAOImpl();
	
	@Override
	public HashMap<String, Object> contentlist(HttpServletRequest request) {
		
		HashMap<String, Object> map = new HashMap<>();
		
		int page = 1;
		String paramPage = request.getParameter("page");
		if(paramPage != null)page = Integer.parseInt(paramPage);
		
		HttpSession session = request.getSession();
		MemberVO member = (MemberVO)session.getAttribute("loginMember");
		
		int totalCount = dao.getTotalCount(member.getM_id());
		int perPageNum = page * 10;
		boolean isNext = true;
		
		if(perPageNum >= totalCount) {
			perPageNum = totalCount;
			isNext = false;
		}
		
		ArrayList<SearchRankVO> rankList = dao.getSearchRankList();
		
		ArrayList<ContentVO> list 
			= dao.getContentList(member.getM_id(), perPageNum);
		
		map.put("rankList", rankList);
		map.put("isNext", isNext);
		map.put("contentList", list);
		
		return map;
	}
	
	@Override
	public HashMap<String, Object> search(HttpServletRequest request) {
		
		HashMap<String, Object> map = new HashMap<>();
		
		int page = 1;
		if(request.getParameter("page") != null) {
			page = Integer.parseInt(request.getParameter("page"));
		}
		
		HttpSession session = request.getSession();
		MemberVO member = (MemberVO)session.getAttribute("loginMember");

		String sc_content = request.getParameter("sc_content");
		String sc_gender = member.getM_gender();
		String sc_birth = member.getM_birth();
		String sc_id = member.getM_id();
		
		System.out.println("page : " + page);
		System.out.println("sc_content : " + sc_content);
		System.out.println("sc_gender : " + sc_gender);
		System.out.println("sc_birth : " + sc_birth);
		System.out.println("sc_id : " + sc_id);
		
		SearchContentVO sc = new SearchContentVO(sc_content, sc_birth, sc_gender, sc_id);
		searchDAO.insertSearch(sc);
		
		int totalCount = searchDAO.getSearchListCount(sc_content);
		
		int perPageNum = page * 20;
		boolean isNext = true;
		
		if(perPageNum >= totalCount) {
			perPageNum = totalCount;
			isNext = false;
		}
		
		System.out.println("totalCount : " + totalCount);
		System.out.println("perPageNum : " + perPageNum);
		System.out.println("isNext : " + isNext);
		
		ArrayList<SearchRankVO> rankList = dao.getSearchRankList();
		ArrayList<ContentVO> searchList = searchDAO.getSearchList(sc_content, perPageNum);
		
		map.put("rankList", rankList);
		map.put("isNext", isNext);
		map.put("searchList", searchList);
		
		return map;
	}

	@Override
	public ArrayList<MemberVO> getSearchNick(HttpServletRequest request) {
		
		String searchValue = request.getParameter("searchValue");
		
		return dao.getSearchNick(searchValue);
	}
	
	
}


