package service;

import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import dao.FollowDAO;
import dao.FollowDAOImpl;
import dao.MemberDAO;
import dao.MemberDAOImpl;
import vo.FollowVO;
import vo.MemberVO;

public class FollowServiceImpl implements FollowService{
	
	FollowDAO dao = new FollowDAOImpl();
	MemberDAO mdao = new MemberDAOImpl();

	@Override
	public void followClick(HttpServletRequest request) {
		
		String following_id = request.getParameter("following_id");
		String follower_id = request.getParameter("follower_id");
		dao.clickFollow(new FollowVO(following_id, follower_id));
	}

	@Override
	public boolean isFollow(HttpServletRequest request) {
		
		String following_id = request.getParameter("following_id");
		String follower_id = request.getParameter("follower_id");
		return dao.isFollow(new FollowVO(following_id, follower_id));
	}

	@Override
	public HashMap<String, Object> getFollowList(HttpServletRequest request) {
		
		HashMap<String, Object> map = new HashMap<>();
		String following_id = request.getParameter("following_id");

		ArrayList<MemberVO> memberList = dao.getFollowList(following_id);
	//	ArrayList<MemberVO> memberList = mdao.getFollowList(followList);
		map.put("followMemberList", memberList);
		
		return map;
	}
}
