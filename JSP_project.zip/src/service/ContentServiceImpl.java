package service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import dao.ContentDAO;
import dao.ContentDAOImpl;
import dao.LikeContentDAO;
import dao.LikeContentDAOImpl;
import vo.ContentVO;

public class ContentServiceImpl implements ContentService{
	
	ContentDAO dao = new ContentDAOImpl();

	@Override
	public boolean writeContent(HttpServletRequest request) {
		
		String saveDir = "/upload";
		
		ContentVO content = null;
		
		try {
			String realPath = request.getServletContext().getRealPath(saveDir);
			
			MultipartRequest multi = 
					new MultipartRequest(request, realPath, 1024*1024*5, "utf-8", new DefaultFileRenamePolicy());
			System.out.println("multi : " + multi);
			
			String c_writer_id = multi.getParameter("c_writer_id");
			String c_nick = multi.getParameter("c_nick");
			String c_content = multi.getParameter("c_content");
			c_content = addLink(c_content);
			
			String file = (String)multi.getFileNames().nextElement();
			String c_img = multi.getFilesystemName(file);
			String c_writer_file = multi.getParameter("c_writer_file");
			
			content = new ContentVO(c_writer_id, c_nick, c_content, c_img, c_writer_file);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return dao.writeContent(content);
	}

	//	글 작성시 들어간 해쉬태그 처리용 메소드
	private String addLink(String text) {
		
		int length = text.length();
		int strIndex = 0;
		int hashIndex = text.indexOf("#");
		
		ArrayList<String> list = new ArrayList<>();
		
		while(hashIndex >= 0) {
			strIndex = text.indexOf(" ", hashIndex);
			int tempIndex = text.indexOf("\n", hashIndex);
			
			System.out.println("tempIndex : " + tempIndex);
			
			if(strIndex > 0 && tempIndex > 0 && (strIndex > tempIndex)) strIndex = tempIndex-1;
			
			if(strIndex >= 0) {
				list.add(text.substring(hashIndex, strIndex));
				hashIndex = text.indexOf("#", strIndex);
			}else {
				list.add(text.substring(hashIndex, length));
				break;
			}
		}
		
		if(list != null) {
			for(String s : list) {
				String changeStr = "<a href=\"contentList.dh?searchValue="+"#"+s+"\">"+s+"</a>"; 
				text = text.replace(s, changeStr);
			}
			text = text.replaceAll("##", "%23");
		}
		return text;
	}

	@Override
	public void getContent(HttpServletRequest request) {

		int c_num = Integer.parseInt(request.getParameter("c_num"));
		
		ContentVO content = dao.getContent(c_num);
		
		request.setAttribute("content", content);
	}

	@Override
	public boolean deleteContent(HttpServletRequest request) {
		
		int c_num = Integer.parseInt(request.getParameter("c_num"));
		String c_writer_id = request.getParameter("c_writer_id");
		ContentVO content = dao.getContent(c_num);
		boolean isSuccess = dao.deleteContent(c_num, c_writer_id);
		
		if(isSuccess) {
			if(content.getC_img() == null || !content.getC_img().equals("")) {
				String realPath = request.getServletContext().getRealPath("/upload");
				String c_img = content.getC_img();
				System.out.println(c_img);
				String filePath = realPath + "/" + c_img;
				File file = new File(filePath);
				file.delete();
			}
			
		}
		return isSuccess;
	}

	@Override
	public void imgDown(HttpServletRequest request, HttpServletResponse response) {
		
		String realPath = request.getServletContext().getRealPath("/upload");
		String c_img = request.getParameter("c_img");
		System.out.println(c_img);
		String filePath = realPath + "/" + c_img;
		System.out.println(filePath);
		String mimeType = request.getServletContext().getMimeType(filePath);
		System.out.println(mimeType);
		
		if(mimeType == null) mimeType = "application/octet_stream";
		response.setContentType(mimeType);
		
		try {
			String agent = request.getHeader("User-Agent");
			if(agent.indexOf("MSIE") > -1 || agent.indexOf("Trident") > -1) {
				c_img = URLEncoder.encode(c_img, "utf-8").replaceAll("\\+", "%20");
			}else {
				c_img = new String(c_img.getBytes("utf-8"), "iso-8859-1");
			}
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		
		response.setHeader("Content-Disposition", "attachment;fileName="+c_img);
		
		try {
			FileInputStream fis = new FileInputStream(filePath);
			OutputStream os = response.getOutputStream();
			
			byte[] bytes = new byte[4096];
			int numRead = 0;
			while((numRead = fis.read(bytes, 0, bytes.length)) != -1) {
				os.write(bytes, 0, numRead);
			}
			os.flush();
			os.close();
			fis.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public HashMap<String, Object> getWritingList(HttpServletRequest request) {
		
		HashMap<String, Object> map = new HashMap<>();
		String c_writer_id = request.getParameter("c_writer_id");
		int page = Integer.parseInt(request.getParameter("page"));
		int totalCount = dao.getWritingCount(c_writer_id);
		int perPageNum = page * 10;
		boolean isNext = true;
		
		if(perPageNum >= totalCount) {
			perPageNum = totalCount;
			isNext = false;
		}
		
		ArrayList<ContentVO> list = dao.getWritingList(c_writer_id, perPageNum);
		map.put("writingList", list);
		map.put("isNext", isNext);
		
		return map;
	}

	@Override
	public HashMap<String, Object> getLikeContentList(HttpServletRequest request) {
		
		HashMap<String, Object> map = new HashMap<>();
		String lc_id = request.getParameter("lc_id");
		int page = Integer.parseInt(request.getParameter("page"));
		int totalCount = dao.getLikeContentCount(lc_id);
		int perPageNum = page * 10;
		boolean isNext = true;
		
		if(perPageNum >= totalCount) {
			perPageNum = totalCount;
			isNext = false;
		}
		
		ArrayList<ContentVO> list = dao.getLikeContentList(lc_id, perPageNum);
		map.put("likeContentList", list);
		map.put("isNext", isNext);
		
		return map;
	}
}
