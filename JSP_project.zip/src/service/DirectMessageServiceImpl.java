package service;

import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.google.gson.JsonElement;

import dao.DirectMessageDAO;
import dao.DirectMessageDAOImpl;
import vo.DMUserList;
import vo.DirectMessageVO;
import vo.MemberVO;

public class DirectMessageServiceImpl implements DirectMessageService{

	DirectMessageDAO dao = new DirectMessageDAOImpl();
	
	@Override
	public void getDMList(HttpServletRequest request) {

		HttpSession session = request.getSession();
		MemberVO loginMember = (MemberVO)session.getAttribute("loginMember");
		String lmID = loginMember.getM_id();
		
		ArrayList<String> userIDList = dao.getUserList(lmID); 
		ArrayList<DMUserList> dmUserList = new ArrayList<>();

		for(String id : userIDList) {
			
			String message = dao.getDMforList(lmID, id);
			if(message != null) {
				MemberVO member = dao.getUserInfo(id);
				
				DMUserList dm = new DMUserList();
				dm.setDm_user_id(id);
				dm.setDm_message(message);
				dm.setDm_user_nick(member.getM_nick());
				dm.setDm_user_file(member.getM_file());
				dmUserList.add(dm);
			}
		}
		request.setAttribute("dmUserList", dmUserList);
	}

	@Override
	public HashMap<String, Object> getDirectMessage(HttpServletRequest request) {

		HashMap<String, Object> map = new HashMap<>();
		HttpSession session = request.getSession();
		MemberVO loginMember = (MemberVO)session.getAttribute("loginMember");
		String user_id = loginMember.getM_id();
		String dm_id = request.getParameter("dm_id");
		
		MemberVO member = dao.getUserInfo(dm_id);
		ArrayList<DirectMessageVO> dmList = dao.getDirectMessage(user_id, dm_id);
		
		map.put("dmUser", member);
		map.put("dmList", dmList);
		
		return map;
	}

	@Override
	public boolean sendDirectMessage(HttpServletRequest request) {

		HttpSession session = request.getSession();
		MemberVO loginMember = (MemberVO)session.getAttribute("loginMember");
		String dm_send_id = loginMember.getM_id();
		String dm_receive_id = request.getParameter("dm_receive_id");
		String dm_content = request.getParameter("dm_content");
		
		return dao.sendDirectMessage(new DirectMessageVO(dm_send_id, dm_receive_id, dm_content));
	}
	
	
}
