package service;

import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import dao.CommentDAO;
import dao.CommentDAOImpl;
import vo.CommentVO;
import vo.Criteria;
import vo.PageMaker;

public class CommentServiceImpl implements CommentService{
	
	CommentDAO dao = new CommentDAOImpl();

	@Override
	public boolean insertComment(HttpServletRequest request) {
		
		String com_writer_id = request.getParameter("com_writer_id");
		String com_writer_nick = request.getParameter("com_writer_nick");
		int com_content_num = Integer.parseInt(request.getParameter("com_content_num"));
		String com_content = request.getParameter("com_content");
		String com_writer_file = request.getParameter("com_writer_file");
		
		CommentVO comment = new CommentVO(com_writer_id, com_writer_nick, com_content_num, com_content, com_writer_file);
		
		return dao.insertComment(comment);
	}

	@Override
	public HashMap<String, Object> getCommentList(HttpServletRequest request) {

		HashMap<String, Object> map = new HashMap<>();
		
		int page = 1;
		int com_content_num = Integer.parseInt(request.getParameter("com_content_num"));
		
		String pageNum = request.getParameter("page");
		
		if(pageNum != null) {
			page = Integer.parseInt(pageNum);
		}
		
		int totalCount = dao.getTotalCount(com_content_num);
		
		Criteria cri = new Criteria(page, 5);
		PageMaker pm = new PageMaker();
		pm.setCri(cri);
		pm.setTotalCount(totalCount);
		
		ArrayList<CommentVO> list = dao.getCommentList(com_content_num, cri);
		
		map.put("pm", pm);
		map.put("list", list);
		
		return map;
	}

	@Override
	public boolean deleteComment(HttpServletRequest request) {
		String com_writer_id = request.getParameter("com_writer_id");
		int com_num = Integer.parseInt(request.getParameter("com_num"));
		return dao.deleteComment(com_num, com_writer_id);
	}
}
