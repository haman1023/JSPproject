package service;

import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import dao.LikeContentDAO;
import dao.LikeContentDAOImpl;
import vo.LikeContentVO;

public class LikeContentServiceImpl implements LikeContentService{

	LikeContentDAO dao = new LikeContentDAOImpl();
	
	@Override
	public HashMap<String, Object> getLike(HttpServletRequest request) {
		
		HashMap<String, Object> map = new HashMap<>();
		
		int lc_num = Integer.parseInt(request.getParameter("lc_num"));
		String lc_id = request.getParameter("lc_id");
		
		boolean isLike = dao.isLike(lc_num, lc_id);
		map.put("isLike", isLike);
		
		int likeCount = dao.getLikeCount(lc_num);
		map.put("likeCount", likeCount);
		
		ArrayList<LikeContentVO> list = dao.getLikeList(lc_num);
		map.put("likeList", list);
		
		System.out.println("map : " + map);
		
		return map;
	}

	@Override
	public void clickLike(HttpServletRequest request) {
		
		int lc_num = Integer.parseInt(request.getParameter("lc_num"));
		String lc_id = request.getParameter("lc_id");
		String lc_file = request.getParameter("lc_file");
		
		dao.clickLike(new LikeContentVO(lc_num, lc_id, lc_file)); 
	}
}
