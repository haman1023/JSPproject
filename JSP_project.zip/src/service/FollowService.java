package service;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import com.google.gson.JsonElement;

public interface FollowService {

	/**
	 * 팔로우 하기 / 끊기
	 * @param request - 팔로우 버튼을 누른 회원정보, 팔로우 버튼이 눌러진 회원정보
	 */
	void followClick(HttpServletRequest request);

	/**
	 * 팔로우 상태 확인
	 * @param request - 팔로우 버튼을 누른 회원정보, 팔로우 버튼이 눌러진 회원정보
	 * @return - 팔로우 상태
	 */
	boolean isFollow(HttpServletRequest request);

	/**
	 * 특정 회원이 팔로우한 목록 불러오기
	 * @param request - 회원 아이디
	 * @return - 팔로우 한 회원 목록
	 */
	HashMap<String, Object> getFollowList(HttpServletRequest request);

}
