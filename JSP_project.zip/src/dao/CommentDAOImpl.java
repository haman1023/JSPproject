package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import util.DBCPUtil;
import vo.CommentVO;
import vo.Criteria;

public class CommentDAOImpl implements CommentDAO{
	
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	@Override
	public boolean insertComment(CommentVO comment) {
		
		boolean isInsert = false;
		
		conn = DBCPUtil.getConnection();
		
		String sql = "INSERT INTO comment VALUES(null, ?, ?, ?, ?, now(), ?)";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, comment.getCom_writer_id());
			pstmt.setString(2, comment.getCom_writer_nick());
			pstmt.setInt(3, comment.getCom_content_num());
			pstmt.setString(4, comment.getCom_content());
			pstmt.setString(5, comment.getCom_writer_file());
			int result = pstmt.executeUpdate();
			
			if(result > 0) isInsert = true;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBCPUtil.close(pstmt, conn);
		}
		return isInsert;
	}

	@Override
	public boolean deleteComment(int com_num, String com_writer_id) {

		boolean isDelete = false;
		
		conn = DBCPUtil.getConnection();
		
		String sql = "DELETE FROM comment WHERE com_num=? AND com_writer_id=?";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, com_num);
			pstmt.setString(2, com_writer_id);
			int result = pstmt.executeUpdate();
			
			if(result > 0) isDelete = true;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBCPUtil.close(pstmt, conn);
		}
		return isDelete;
	}

	@Override
	public int getTotalCount(int com_content_num) {
		
		int totalCount = 0;
		
		conn = DBCPUtil.getConnection();
		
		String sql = "SELECT count(*) FROM comment WHERE com_content_num=?";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, com_content_num);
			rs = pstmt.executeQuery();
			
			if(rs.next()) totalCount = rs.getInt(1);
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBCPUtil.close(rs, pstmt, conn);
		}
		return totalCount;
	}

	@Override
	public ArrayList<CommentVO> getCommentList(int com_content_num, Criteria cri) {
		
		ArrayList<CommentVO> list = null;
		
		conn = DBCPUtil.getConnection();
		
		String sql = "SELECT * FROM comment WHERE com_content_num=? ORDER BY com_date DESC limit ?,?";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, com_content_num);
			pstmt.setInt(2, cri.getPageStart());
			pstmt.setInt(3, cri.getPerPageNum());
			rs = pstmt.executeQuery();
			
			list = new ArrayList<>();
			while(rs.next()) {
				list.add(new CommentVO(rs.getInt(1),
										rs.getString(2),
										rs.getString(3),
										rs.getInt(4),
										rs.getString(5),
										rs.getTimestamp(6),
										rs.getString(7)));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBCPUtil.close(rs, pstmt, conn);
		}
		return list;
	}
	
}
