package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import util.DBCPUtil;
import vo.LikeContentVO;

public class LikeContentDAOImpl implements LikeContentDAO{

	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	@Override
	public int getLikeCount(int c_num) {
		
		int likeCount = 0;
		
		conn = DBCPUtil.getConnection();
		
		String sql = "SELECT count(*) FROM like_content WHERE lc_num=?";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, c_num);
			rs = pstmt.executeQuery();
			
			if(rs.next()) likeCount = rs.getInt(1);
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBCPUtil.close(rs, pstmt, conn);
		}
		return likeCount;
	}

	@Override
	public ArrayList<LikeContentVO> getLikeList(int c_num) {
		
		ArrayList<LikeContentVO> list = new ArrayList<>();
		
		conn = DBCPUtil.getConnection();
		
		String sql = "SELECT lc_id, lc_file FROM like_content WHERE lc_num=? limit 3";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, c_num);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
//				list.add(rs.getString(1));
				list.add(new LikeContentVO(rs.getString(1), rs.getString(2)));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBCPUtil.close(rs, pstmt, conn);
		}
		return list;
	}

	@Override
	public void clickLike(LikeContentVO content) {

		conn = DBCPUtil.getConnection();
		
		String sql = "SELECT * FROM like_content WHERE lc_num=? AND lc_id=?";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, content.getLc_num());
			pstmt.setString(2, content.getLc_id());
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				sql = "DELETE FROM like_content WHERE lc_num=? AND lc_id=?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, content.getLc_num());
				pstmt.setString(2, content.getLc_id());
				pstmt.executeUpdate();
			}else {
				sql = "INSERT INTO like_content VALUES(?, ?, ?)";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, content.getLc_num());
				pstmt.setString(2, content.getLc_id());
				pstmt.setString(3, content.getLc_file());
				pstmt.executeUpdate();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBCPUtil.close(rs, pstmt, conn);
		}
	}

	@Override
	public boolean isLike(int lc_num, String lc_id) {
		
		boolean isLike = false;
		
		conn = DBCPUtil.getConnection();
		
		String sql = "SELECT * FROM like_content WHERE lc_num=? AND lc_id=?";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, lc_num);
			pstmt.setString(2, lc_id);
			rs = pstmt.executeQuery();
			
			if(rs.next()) isLike = true;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBCPUtil.close(rs, pstmt, conn);
		}
		return isLike;
	}
}
