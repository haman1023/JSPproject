package dao;

import java.util.ArrayList;

import vo.ContentVO;

public interface ContentDAO {

	/**
	 * 글 작성
	 * @param content - 글내용(아이디, 닉네임, 글내용, 사진)
	 * @return - 성공 여부
	 */
	boolean writeContent(ContentVO content);

	/**
	 * 글 가져오기
	 * @param c_num - 글번호
	 * @return c_num에 해당하는 컨텐츠
	 */
	ContentVO getContent(int c_num);

	/**
	 * 글 삭제
	 * @param c_num - 글번호
	 * @param c_writer_id - 작성자 아이디
	 * @return - 성공 여부
	 */
	boolean deleteContent(int c_num, String c_writer_id);

	/**
	 * 특정회원이 쓴 글 리스트
	 * @param c_writer_id - 회원 아이디
	 * @param perPageNum - 불러올 글 개수
	 * @return - 회원이 쓴 글 리스트
	 */
	ArrayList<ContentVO> getWritingList(String c_writer_id, int perPageNum);

	/**
	 * 특정 회원이 좋아요 누른 리스트
	 * @param lc_id - 회원 아이디
	 * @param perPageNum  - 불러올 글 개수
	 * @return - 좋아요 누른 리스트
	 */
	ArrayList<ContentVO> getLikeContentList(String lc_id, int perPageNum);

	/**
	 * 특정 회원이 쓴 글의 총 개수
	 * @param c_writer_id - 회원 아이디
	 * @return - 글 개수
	 */
	int getWritingCount(String c_writer_id);

	/**
	 * 특정 회원이 좋아요 누른 총 개수
	 * @param lc_id - 회원 아이디 
	 * @return - 좋아요 누글 글 개수
	 */
	int getLikeContentCount(String lc_id);

}
