package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import util.DBCPUtil;
import vo.FollowVO;
import vo.MemberVO;

public class FollowDAOImpl implements FollowDAO{
	
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	@Override
	public void clickFollow(FollowVO follow) {
		
		conn = DBCPUtil.getConnection();
		
		String sql = "SELECT * FROM follow WHERE following_id=? AND follower_id=?";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, follow.getFollowing_id());
			pstmt.setString(2, follow.getFollower_id());
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				sql = "DELETE FROM follow WHERE following_id=? AND follower_id=?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, follow.getFollowing_id());
				pstmt.setString(2, follow.getFollower_id());
				pstmt.executeUpdate();
			}else {
				sql = "INSERT INTO follow VALUES(?, ?)";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, follow.getFollowing_id());
				pstmt.setString(2, follow.getFollower_id());
				pstmt.executeUpdate();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBCPUtil.close(rs, pstmt, conn);
		}
	}

	@Override
	public boolean isFollow(FollowVO follow) {
		
		boolean isFollow = false;
		conn = DBCPUtil.getConnection();
		
		String sql = "SELECT * FROM follow WHERE following_id=? AND follower_id=?";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, follow.getFollowing_id());
			pstmt.setString(2, follow.getFollower_id());
			rs = pstmt.executeQuery();
			if(rs.next()) isFollow = true;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBCPUtil.close(rs, pstmt, conn);
		}
		return isFollow;
	}

	@Override
	public ArrayList<MemberVO> getFollowList(String following_id) {

		ArrayList<MemberVO> list = null;
		conn = DBCPUtil.getConnection();
		
		String sql = "SELECT * FROM member WHERE m_id in (SELECT follower_id FROM follow WHERE following_id=?)";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, following_id);
			rs = pstmt.executeQuery();
			list = new ArrayList<>();
			
			while(rs.next()) {
				list.add(new MemberVO(rs.getString(1),
						rs.getString(2),
						rs.getString(3),
						rs.getString(4),
						rs.getString(5),
						rs.getString(6),
						rs.getTimestamp(7),
						rs.getString(8),
						rs.getString(9)));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBCPUtil.close(rs, pstmt, conn);
		}
		return list;
	}
}
