package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import util.DBCPUtil;
import vo.DirectMessageVO;
import vo.MemberVO;

public class DirectMessageDAOImpl implements DirectMessageDAO{

	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	@Override
	public ArrayList<String> getUserList(String m_id) {
		
		ArrayList<String> list = null;
		conn = DBCPUtil.getConnection();
		
		String sql = "SELECT m_id FROM member WHERE m_id != ?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, m_id);
			rs = pstmt.executeQuery();
			
			list = new ArrayList<>();
			while(rs.next()) {
				list.add(rs.getString(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBCPUtil.close(rs, pstmt, conn);
		}
		return list;
	}

	@Override
	public String getDMforList(String user_id, String dm_id) {
		
		String dm = null;
		conn = DBCPUtil.getConnection();
		
		String sql = "SELECT dm_content FROM direct_message"
					+ " WHERE (dm_send_id=? AND dm_receive_id=?)"
					+ " OR (dm_send_id=? AND dm_receive_id=?) limit 1";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, user_id);
			pstmt.setString(2, dm_id);
			pstmt.setString(3, dm_id);
			pstmt.setString(4, user_id);
			rs = pstmt.executeQuery();
			
			if(rs.next()) dm = rs.getString(1);
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBCPUtil.close(rs, pstmt, conn);
		}
		return dm;
	}

	@Override
	public MemberVO getUserInfo(String id) {
		
		MemberVO member = null;
		conn = DBCPUtil.getConnection();
		
		String sql = "SELECT * FROM member WHERE m_id=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			
			member = new MemberVO();
			if(rs.next()) {
				member.setM_id(rs.getString("m_id"));
				member.setM_nick(rs.getString("m_nick"));
				member.setM_file(rs.getString("m_file"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBCPUtil.close(rs, pstmt, conn);
		}
		return member;
	}

	@Override
	public ArrayList<DirectMessageVO> getDirectMessage(String user_id, String dm_id) {
		ArrayList<DirectMessageVO> list = null;
		conn = DBCPUtil.getConnection();
		
		String sql = "SELECT * FROM direct_message"
					+ " WHERE (dm_send_id=? AND dm_receive_id=?)"
					+ " OR (dm_send_id=? AND dm_receive_id=?) ORDER BY dm_date";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, user_id);
			pstmt.setString(2, dm_id);
			pstmt.setString(3, dm_id);
			pstmt.setString(4, user_id);
			rs = pstmt.executeQuery();
			
			list = new ArrayList<>();

			while(rs.next()) {
				list.add(new DirectMessageVO(rs.getString(1),
											rs.getString(2),
											rs.getString(3),
											rs.getTimestamp(4)));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBCPUtil.close(rs, pstmt, conn);
		}
		return list;
	}

	@Override
	public boolean sendDirectMessage(DirectMessageVO dm) {
		
		boolean isSuccess = false;
		conn = DBCPUtil.getConnection();
		
		String sql = "INSERT INTO direct_message VALUES(?,?,?,now())";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dm.getDm_send_id());
			pstmt.setString(2, dm.getDm_receive_id());
			pstmt.setString(3, dm.getDm_content());
			int result = pstmt.executeUpdate();
			
			if(result > 0) isSuccess = true;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBCPUtil.close(rs, pstmt, conn);
		}
		return isSuccess;
	}
}
