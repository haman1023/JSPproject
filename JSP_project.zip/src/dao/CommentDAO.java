package dao;

import java.util.ArrayList;

import vo.CommentVO;
import vo.Criteria;

public interface CommentDAO {
	
	/**
	 * 댓글 작성
	 * @param comment - 댓글내용(작성 아이디, 작성 닉네임, 작성내용, 작성한 글 번호)
	 * @return - 성공 여부
	 */
	boolean insertComment(CommentVO comment);

	/**
	 * 댓글 삭제
	 * @param com_num - 댓글 번호
	 * @param com_writer_id - 댓글 작성자
	 * @return - 성공 여부
	 */
	boolean deleteComment(int com_num, String com_writer_id);

	/**
	 * 총 댓글의 개수 구하기
	 * @param com_content_num - 게시물 번호
	 * @return 게시물의 총 댓글 개수
	 */
	int getTotalCount(int com_content_num);

	/**
	 * 페이징 처리된 댓글 리스트
	 * @param com_content_num - 게시글 번호
	 * @param cri - 페이징 처리를 위한 정보
	 * @return 요청된 페이지 번호의 댓글 리스트
	 */
	ArrayList<CommentVO> getCommentList(int com_content_num, Criteria cri);

}
