package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import util.DBCPUtil;
import vo.ContentVO;
import vo.Criteria;
import vo.MemberVO;
import vo.PageMaker;
import vo.SearchContentVO;
import vo.SearchCriteria;
import vo.SearchRankVO;

public class ListDAOImpl implements ListDAO {

	Connection conn;
	PreparedStatement pstmt;
	ResultSet rs;

	@Override
	public ArrayList<ContentVO> getContentList(String m_id, int perPageNum) {

		ArrayList<ContentVO> list = new ArrayList<>();

		String sql = "SELECT * FROM content WHERE c_writer_id in (SELECT follower_id FROM follow WHERE following_id = ?)"
				+ " OR c_writer_id=?" + " OR c_content LIKE '%@" + m_id + "%'" + " ORDER BY c_date DESC limit ?";
		conn = DBCPUtil.getConnection();

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, m_id);
			pstmt.setString(2, m_id);
			pstmt.setInt(3, perPageNum);

			rs = pstmt.executeQuery();

			while (rs.next()) {
				ContentVO content = new ContentVO();
				content.setC_num(rs.getInt("c_num"));
				content.setC_writer_id(rs.getString("c_writer_id"));
				content.setC_nick(rs.getString("c_nick"));
				content.setC_content(rs.getString("c_content"));
				content.setC_img(rs.getString("c_img"));
				content.setC_writer_file(rs.getString("c_writer_file"));
				content.setC_date(rs.getTimestamp("c_date"));
				list.add(content);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBCPUtil.close(rs, pstmt, conn);
		}
		return list;
	}

	@Override
	public int getTotalCount(String m_id) {

		int totalCount = 0;

		String sql = "SELECT count(*) FROM content WHERE c_writer_id in (SELECT follower_id FROM follow WHERE following_id = ?)"
				+ " OR c_writer_id=?" + " OR c_content LIKE '%@" + m_id + "%'";

		conn = DBCPUtil.getConnection();

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, m_id);
			pstmt.setString(2, m_id);
			rs = pstmt.executeQuery();
			if (rs.next())
				totalCount = rs.getInt(1);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBCPUtil.close(rs, pstmt, conn);
		}
		return totalCount;
	}

	@Override
	public ArrayList<SearchRankVO> getSearchRankList() {
		ArrayList<SearchRankVO> ranklist = new ArrayList<>();
		
		String sql = "SELECT sc_content, count(*) FROM search_content WHERE sc_date > date_sub(now(), INTERVAL 24 HOUR)"
				 	+ " GROUP BY sc_content ORDER BY count(*) DESC, sc_content limit 10";
		
		conn = DBCPUtil.getConnection();
		
		try {
			pstmt = conn.prepareStatement(sql);
			rs=pstmt.executeQuery();
			while(rs.next()){
				SearchRankVO vo = new SearchRankVO(rs.getString(1), rs.getInt(2));
				ranklist.add(vo);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {DBCPUtil.close(rs,pstmt,conn);}
		return ranklist;
	}

	@Override
	public ArrayList<MemberVO> getSearchNick(String searchValue) {

		ArrayList<MemberVO> list = null;
		conn = DBCPUtil.getConnection();
		
		String sql = "SELECT * FROM member WHERE m_nick LIKE CONCAT('%',?,'%')";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, searchValue);
			rs = pstmt.executeQuery();
			list = new ArrayList<>();
			while(rs.next()){
				MemberVO member = new MemberVO();
				member.setM_id(rs.getString("m_id"));
				member.setM_nick(rs.getString("m_nick"));
				member.setM_file(rs.getString("m_file"));
				list.add(member);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {DBCPUtil.close(rs,pstmt,conn);}
		return list;
	}
}
