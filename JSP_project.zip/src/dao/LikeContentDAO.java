package dao;

import java.util.ArrayList;

import vo.LikeContentVO;

public interface LikeContentDAO {

	/**
	 * 게시글의 좋아요 한 사람 숫자
	 * @param c_num - 게시글 번호
	 * @return 좋아요 한 사람 숫자
	 */
	int getLikeCount(int c_num);

	/**
	 * 게시글에 좋아요 한 사람 리스트
	 * @param c_num - 게시글 번호
	 * @return 좋아요 한 사람 리스트
	 */
	ArrayList<LikeContentVO> getLikeList(int c_num);

	/**
	 * 게시글에서 좋아요 클릭
	 * @param likeContentVO - 게시글 번호, 사용자 아이디, 사용자 그림파일
	 */
	void clickLike(LikeContentVO likeContentVO);

	/**
	 * 좋아요 상태 알아보기
	 * @param lc_num - 게시글 번호
	 * @param lc_id - 사용자 아이디
	 * @param lc_file 
	 * @return 현재 좋아요 상태
	 */
	boolean isLike(int lc_num, String lc_id);
}
