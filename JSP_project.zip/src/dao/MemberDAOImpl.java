package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import util.DBCPUtil;
import vo.ContentVO;
import vo.MemberVO;

public class MemberDAOImpl implements MemberDAO{
	
	Connection conn;
	PreparedStatement pstmt;
	ResultSet rs;
	
	// 회원가입
	@Override
	public boolean memberJoin(MemberVO member) {
		conn = DBCPUtil.getConnection();
		
		try {
			String  sql = "SELECT * FROM member WHERE m_id=? ";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, member.getM_id());
			rs = pstmt.executeQuery();
			if(rs.next())return false;
			
			sql = "INSERT INTO member(m_id,m_pass,m_nick,m_email,m_birth,m_gender,m_date)" + "VALUES(?,?,?,?,?,?,now())";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, member.getM_id());
			pstmt.setString(2, member.getM_pass());
			pstmt.setString(3, member.getM_nick());
			pstmt.setString(4, member.getM_email());
			pstmt.setString(5, member.getM_birth());
			pstmt.setString(6, member.getM_gender());
			
			int result = pstmt.executeUpdate();
			if(result <= 0) return false;
		} catch (Exception e) {
			System.out.println("회원가입 실패 : " + e.getMessage());
			return false;
		}finally {
			DBCPUtil.close(rs);
			DBCPUtil.close(pstmt);
			DBCPUtil.close(conn);
		}
		return true;
	}
	
	// 로그인 체크
	@Override
	public MemberVO memberLogin(String m_id, String m_pass) {
		MemberVO member = null;
		conn = DBCPUtil.getConnection();
		
		try {
			String sql = "SELECT * FROM member WHERE m_id=? AND m_pass=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, m_id);
			pstmt.setString(2, m_pass);
			rs = pstmt.executeQuery();
			// 정보 일치 회원확인
			if(rs.next()) {
				member = setMemberVO(rs);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			DBCPUtil.close(rs);
			DBCPUtil.close(pstmt);
			DBCPUtil.close(conn);
		}
		return member;
	}

	// 로그인
	@Override
	public MemberVO getMemberById(String m_id) {
		MemberVO member = null;
		
		conn = DBCPUtil.getConnection();
		
		try {
			String sql = "SELECT * FROM member WHERE m_id = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, m_id);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				member = setMemberVO(rs);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DBCPUtil.close(rs);
			DBCPUtil.close(pstmt);
			DBCPUtil.close(conn);
		}
		return member;
	}
	
	// 회원 탈퇴시 정보 삭제
	@Override
	public void deleteMember(String m_id) {
		conn = DBCPUtil.getConnection();
		try {
			String sql = "DELETE FROM member WHERE m_id=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, m_id);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBCPUtil.close(pstmt);
			DBCPUtil.close(conn);
		}
	}
	
	// 아이디 찾기
	// 이메일로 멤버 확인
	// 불린말고 스트링으로 반환해주고 있을때는 아이디 리턴 없을때는 널값리턴
	@Override
	public String checkMember(String m_email) {
		
		String m_id = null;
		
		conn = DBCPUtil.getConnection();
		
		String sql = "SELECT m_id FROM member WHERE m_email = ?";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, m_email);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				return m_id = rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBCPUtil.close(rs);
			DBCPUtil.close(pstmt);
			DBCPUtil.close(conn);
		}
		return m_id;
	}
	
	// 비밀번호 찾기 메일 발송
	// 아이디 이메일로 멤버 확인
	@Override
	public boolean checkMember(String m_id, String m_email) {
		conn = DBCPUtil.getConnection();
		
		String sql = "SELECT * FROM member WHERE m_id = ? AND m_email = ?";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, m_id);
			pstmt.setString(2, m_email);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBCPUtil.close(rs);
			DBCPUtil.close(pstmt);
			DBCPUtil.close(conn);
		}
		return false;
	}

	// 비밀번호 찾기용 임시 코드 등록
	@Override
	public boolean addPassCode(String m_email, String code) {
		try {
			conn = DBCPUtil.getConnection();
			
			String sql = "SELECT * FROM test_code WHERE m_email = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, m_email);
			rs = pstmt.executeQuery();
			
			System.out.println("m_email : " + m_email+", code : " + code);
			
			if(rs.next()) {
				System.out.println("수정완료");
				sql = "UPDATE test_code SET code = ? WHERE m_email = ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, code);
				pstmt.setString(2, m_email);
			}else {
				System.out.println("삽입완료");
				sql = "INSERT INTO test_code VALUES(?,?)";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, m_email);
				pstmt.setString(2, code);
			}
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBCPUtil.close(rs);
			DBCPUtil.close(pstmt);
			DBCPUtil.close(conn);
		}
		return false;
	}
	
	@Override
	public boolean checkPassCode(String m_email, String code) {
		conn = DBCPUtil.getConnection();
		String sql = "SELECT * FROM test_code WHERE m_email = ? AND code = ?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, m_email);
			pstmt.setString(2, code);
			rs = pstmt.executeQuery();
			if(rs.next()) return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBCPUtil.close(rs);
			DBCPUtil.close(pstmt);
			DBCPUtil.close(conn);
		}
		return false;
	}

	// 비밀번호 수정
	@Override
	public void changePass(String m_email, String m_pass) {
		conn = DBCPUtil.getConnection();
		
		try {
			String sql = "UPDATE member SET m_pass = ? WHERE m_email= ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, m_pass);
			pstmt.setString(2, m_email);
			int result = pstmt.executeUpdate();
			
			if(result > 0) {
				sql = "DELETE FROM test_code WHERE m_id = ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, m_email);
				pstmt.executeUpdate();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBCPUtil.close(pstmt);
			DBCPUtil.close(conn);
		}
	}
	
	@Override
	public boolean memberUpdate(MemberVO member) {
		
		boolean isUpdate = false;
		conn = DBCPUtil.getConnection();
		String  sql = "UPDATE member SET m_nick=?, m_comment=?, m_file=? WHERE m_id=? ";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, member.getM_nick());
			pstmt.setString(2, member.getM_comment());
			pstmt.setString(3, member.getM_file());
			pstmt.setString(4, member.getM_id());
			
			int result = pstmt.executeUpdate();
			if(result > 0) isUpdate = true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}finally {
			DBCPUtil.close(pstmt, conn);
		}
		return isUpdate;
	}
	
	@Override
	public String getMemberFile(String m_id) {
		
		String m_file = null;
		conn = DBCPUtil.getConnection();
		String  sql = "SELECT m_file FROM member WHERE m_id=? ";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, m_id);
			rs = pstmt.executeQuery();
			if(rs.next()) m_file = rs.getString(1);
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			DBCPUtil.close(rs, pstmt, conn);
		}
		return m_file;
	}

	//	rs를 MemberVO에 값을 넣어준다.
	private MemberVO setMemberVO(ResultSet rs) throws SQLException {
		return new MemberVO(rs.getString(1),
							rs.getString(2),
							rs.getString(3),
							rs.getString(4),
							rs.getString(5),
							rs.getString(6),
							rs.getTimestamp(7),
							rs.getString(8),
							rs.getString(9));
	}
}