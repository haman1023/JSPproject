package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import util.DBCPUtil;
import vo.ContentVO;
import vo.PageMaker;
import vo.SearchContentVO;
import vo.SearchCriteria;

public class SearchDAOImpl implements SearchDAO{
	
	Connection conn;
	PreparedStatement pstmt;
	ResultSet rs;

	@Override
	public int getSearchListCount(String sc_content) {
		int listCount = 0;
		
		conn = DBCPUtil.getConnection();
		
		String sql = "SELECT count(*) FROM content";
		sql += " WHERE c_content LIKE CONCAT('%',?,'%') OR c_nick LIKE CONCAT('%',?,'%')";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, sc_content);
			pstmt.setString(2, sc_content);
				
			System.out.println(sql);
				
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				listCount = rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBCPUtil.close(rs,pstmt,conn);
		}
		return listCount;
	}

	@Override
	public ArrayList<ContentVO> getSearchList(String sc_content, int perPageNum) {
		ArrayList<ContentVO> searchList = new ArrayList<>();
		
		String sql = "SELECT * FROM content ";
		sql += "WHERE c_content LIKE CONCAT('%',?,'%') OR c_nick LIKE CONCAT('%',?,'%') ";
		sql += "ORDER BY c_date DESC limit ?";
		
		conn = DBCPUtil.getConnection();
		try {
			
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, sc_content);
			pstmt.setString(2, sc_content);
			pstmt.setInt(3, perPageNum);
			
			rs = pstmt.executeQuery();
			while(rs.next()) {
				ContentVO c = new ContentVO();
				c.setC_num(rs.getInt("c_num"));
				c.setC_writer_id(rs.getString("c_writer_id"));
				c.setC_nick(rs.getString("c_nick"));
				c.setC_content(rs.getString("c_content"));
				c.setC_img(rs.getString("c_img"));
				c.setC_writer_file(rs.getString("c_writer_file"));
				c.setC_date(rs.getTimestamp("c_date"));
				searchList.add(c);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBCPUtil.close(rs,pstmt,conn);
		}
		return searchList;
	}

	@Override
	public void insertSearch(SearchContentVO searchValue) {
		System.out.println("search_content 요청");
		
		conn = DBCPUtil.getConnection();
		
		String sql = "SELECT * FROM search_content WHERE sc_content=? AND sc_id=? AND sc_date > date_sub(now(), INTERVAL 5 SECOND)";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, searchValue.getSc_content());
			pstmt.setString(2, searchValue.getSc_id());
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				
			}else {
				sql = "INSERT INTO search_content VALUES(?,?,?,now(),?)";

				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, searchValue.getSc_content());
				pstmt.setString(2, searchValue.getSc_birth());
				pstmt.setString(3, searchValue.getSc_gender());
				pstmt.setString(4, searchValue.getSc_id());
				pstmt.executeUpdate();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			DBCPUtil.close(rs,pstmt,conn);
		}
	}
}

	

