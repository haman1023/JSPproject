package dao;

import vo.MemberVO;

public interface MemberDAO {

	boolean memberJoin(MemberVO member);

	MemberVO memberLogin(String m_id, String m_pass);

	void deleteMember(String m_id);

	String checkMember(String m_email);

	boolean checkMember(String m_id, String m_email);

	boolean addPassCode(String m_email, String code);

	boolean checkPassCode(String m_email, String code);

	void changePass(String m_email, String m_pass);

	MemberVO getMemberById(String m_id);

	boolean memberUpdate(MemberVO member);

	String getMemberFile(String m_id);
}
