package dao;

import java.util.ArrayList;

import vo.ContentVO;
import vo.PageMaker;
import vo.SearchCriteria;
import vo.SearchContentVO;

public interface SearchDAO {

	// 검색 결과에 포함된 게시물 전체개수
	int getSearchListCount(String sc_content);

	void insertSearch(SearchContentVO searchValue);
	
	// 검색 결과에 포함된 게시물 리스트
	ArrayList<ContentVO> getSearchList(String sc_content, int perPageNum);
}
