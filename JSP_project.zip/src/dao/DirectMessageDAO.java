package dao;

import java.util.ArrayList;

import vo.DirectMessageVO;
import vo.MemberVO;

public interface DirectMessageDAO {

	/**
	 * 모든 회원들의 아이디 정보를 가져온다.
	 * @param m_id - 로그인 한 사용자
	 * @return 요청한 사용자를 제외한 모든 사용자 id
	 */
	ArrayList<String> getUserList(String m_id);

	/**
	 * 특정회원들간의 마지막 DM을 가져오기
	 * @param user_id - 로그인한 회원
	 * @param dm_id - 총회원중 한명
	 * @return - 마지막 DM
	 */
	String getDMforList(String user_id, String dm_id);

	/**
	 * 특정 멤버의 정보를 가져오기
	 * @param id - 회원 아이디
	 * @return - 회원정보
	 */
	MemberVO getUserInfo(String id);

	/**
	 * 특정 멤버와 DM한 메세지 목록
	 * @param user_id - 로그인한 회원
	 * @param dm_id - DM대상 회원
	 * @return - DM 메세지 목록
	 */
	ArrayList<DirectMessageVO> getDirectMessage(String user_id, String dm_id);

	/**
	 * 특정 멤버에게 DM메세지 보내기
	 * @param directMessageVO - 보낸사람, 받는사람, 내용
	 * @return 성공여부
	 */
	boolean sendDirectMessage(DirectMessageVO directMessageVO);

}
