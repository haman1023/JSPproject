package dao;

import java.util.ArrayList;

import com.google.gson.JsonElement;

import vo.FollowVO;
import vo.MemberVO;

public interface FollowDAO {

	/**
	 * 팔로우 상태 확인 후 삽입 or 삭제
	 * @param followVO - 팔로우 한 회원, 팔로우 당한 회원
	 */
	void clickFollow(FollowVO follow);

	/**
	 * 현재 팔로우 상태 확인
	 * @param followVO - 팔로우 한 회원, 팔로우 당한 회원
	 * @return - 현재 팔로우 상태
	 */
	boolean isFollow(FollowVO follow);

	/**
	 * 특정회원이 팔로우 한 회원 목록 불러오기
	 * @param following_id - 회원 아이디
	 * @return - 회원이 팔로우한 회원 목록
	 */
	ArrayList<MemberVO> getFollowList(String following_id);

}
