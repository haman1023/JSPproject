package dao;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import vo.ContentVO;
import vo.Criteria;
import vo.MemberVO;
import vo.SearchRankVO;

public interface ListDAO {

	// 게시물 목록
	ArrayList<ContentVO> getContentList(String m_id, int perPageNum);
	
	// 게시물 개수
	int getTotalCount(String m_id);

	/**
	 * 검색어 순위 가져오기
	 * @return - 검색어 순위
	 */
	public ArrayList<SearchRankVO> getSearchRankList();

	/**
	 * 검색중 닉 가져오기
	 * @param searchValue - 검색어
	 * @return 검색어가 포함된 아이디
	 */
	ArrayList<MemberVO> getSearchNick(String searchValue);

	
}
