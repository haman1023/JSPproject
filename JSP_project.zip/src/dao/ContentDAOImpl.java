package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import util.DBCPUtil;
import vo.ContentVO;

public class ContentDAOImpl implements ContentDAO{
	
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;	

	@Override
	public boolean writeContent(ContentVO content) {

		boolean isWrite = false;
		
		conn = DBCPUtil.getConnection();
		
		String sql = "INSERT INTO content VALUES(null, ?, ?, ?, ?, ?, now())";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, content.getC_writer_id());
			pstmt.setString(2, content.getC_nick());
			pstmt.setString(3, content.getC_content());
			pstmt.setString(4, content.getC_img());
			pstmt.setString(5, content.getC_writer_file());
			int result = pstmt.executeUpdate();
			
			if(result > 0) isWrite = true;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBCPUtil.close(pstmt, conn);
		}
		return isWrite;
	}

	@Override
	public ContentVO getContent(int c_num) {
		
		ContentVO content = null;
		
		conn = DBCPUtil.getConnection();
		
		String sql = "SELECT * FROM content WHERE c_num=?";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, c_num);

			rs = pstmt.executeQuery();
			
			if(rs.next()) content = setContent(rs);
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBCPUtil.close(rs, pstmt, conn);
		}
		return content;
	}

	@Override
	public boolean deleteContent(int c_num, String c_writer_id) {
		
		boolean isDelete = false;
		
		conn = DBCPUtil.getConnection();
		
		String sql = "DELETE FROM content WHERE c_num=? AND c_writer_id=?";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, c_num);
			pstmt.setString(2, c_writer_id);
			int result = pstmt.executeUpdate();
			
			if(result > 0) isDelete = true;
		} catch (SQLException e) {
			try {
				isDelete = false;
				conn.rollback();
			} catch (SQLException e1) {}
			e.printStackTrace();
		}finally {
			DBCPUtil.close(pstmt, conn);
		}
		return isDelete;
	}
	
	@Override
	public ArrayList<ContentVO> getWritingList(String c_writer_id, int perPageNum) {

		ArrayList<ContentVO> list = null;
		
		conn = DBCPUtil.getConnection();
		
		String sql = "SELECT * FROM content WHERE c_writer_id=? ORDER BY c_date DESC limit ?";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, c_writer_id);
			pstmt.setInt(2, perPageNum);

			rs = pstmt.executeQuery();
			
			list = new ArrayList<>();
			while(rs.next()) {
				list.add(setContent(rs));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBCPUtil.close(rs, pstmt, conn);
		}
		return list;
	}

	@Override
	public ArrayList<ContentVO> getLikeContentList(String lc_id, int perPageNum) {
		
		ArrayList<ContentVO> list = new ArrayList<>();
		
		conn = DBCPUtil.getConnection();
		
		try {
			String sql = "SELECT * FROM content WHERE c_num in (SELECT lc_num FROM like_content WHERE lc_id = ?)";
			sql += " ORDER BY c_date DESC limit ?";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, lc_id);
			pstmt.setInt(2, perPageNum);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				list.add(setContent(rs));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBCPUtil.close(rs, pstmt, conn);
		}
		return list;
	}
	
	@Override
	public int getWritingCount(String c_writer_id) {
		
		int count = 0;
		
		conn = DBCPUtil.getConnection();
		String sql = "SELECT count(*) FROM content WHERE c_writer_id=?";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, c_writer_id);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				count = rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBCPUtil.close(rs, pstmt, conn);
		}
		return count;
	}

	@Override
	public int getLikeContentCount(String lc_id) {
		
		int count = 0;
		
		conn = DBCPUtil.getConnection();
		String sql = "SELECT count(*) FROM content WHERE c_num in (SELECT lc_num FROM like_content WHERE lc_id = ?)";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, lc_id);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				count = rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBCPUtil.close(rs, pstmt, conn);
		}
		return count;
	}

	//	ContentVO 세팅용 메소드
	private ContentVO setContent(ResultSet rs) throws SQLException{
		return new ContentVO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getTimestamp(7));
	}
}
