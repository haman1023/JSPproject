package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import service.CommentService;
import service.CommentServiceImpl;

@WebServlet("*.co")
public class CommentController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	CommentService service = new CommentServiceImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");
		
		String cmd = request.getRequestURI().substring(request.getContextPath().length()+1);
		
		Gson gson = new Gson();
		
		String json = "";
		
		if(cmd.equals("commentWrite.co")) {
			System.out.println("댓글 등록 요청!");
			json = gson.toJson(service.insertComment(request));
		}
		
		if(cmd.equals("list.co")) {
			json = gson.toJson(service.getCommentList(request));
		}
		
		if(cmd.equals("commentDelete.co")) {
			System.out.println("댓글 삭제 요청!");
			json = gson.toJson(service.deleteComment(request));
		}
		
		response.setContentType("application/json;charset=utf-8");
		response.getWriter().print(json);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
