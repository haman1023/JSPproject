package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import service.ContentService;
import service.ContentServiceImpl;
import service.LikeContentService;
import service.LikeContentServiceImpl;

@WebServlet("*.dh")
public class ContentController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	ContentService service = new ContentServiceImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		
		String cmd = request.getRequestURI().substring(request.getContextPath().length()+1);
		
		String nextPage = null;
		Gson gson = new Gson();
		String json = "";
		
		if(cmd.equals("contentWrite.dh")) {
			System.out.println("글쓰기 페이지 요청");
			nextPage = "/content/content_write.jsp";
		}
		
		if(cmd.equals("contentList.dh")) {
			System.out.println("리스트 페이지 요청");
			nextPage = "/content/content_list.jsp";
		}
		
		if(cmd.equals("contentWriteSubmit.dh")) {
			System.out.println("글쓰기 요청");
			boolean isSuccess = service.writeContent(request);
			
			if(isSuccess) {
				System.out.println("글 작성 완료");
				response.sendRedirect("contentList.dh");
			}else {
				System.out.println("글 작성 실패");
				response.setContentType("text/html;charset=utf-8");
				PrintWriter out = response.getWriter();
				out.print("<script>");
				out.print("alert('글 작성 실패');"); 
				out.print("history.go(-1);");
				out.print("<script>");
			}
		}
		
		if(cmd.equals("contentDetail.dh")) {
			System.out.println("글 상세보기 요청");
			service.getContent(request);
			nextPage = "/content/content_detail.jsp";
		}
		
		if(cmd.equals("contentDelete.dh")) {
			System.out.println("글 삭제 요청");
			boolean isSuccess = service.deleteContent(request);
			if(isSuccess) {
				System.out.println("글 삭제 완료");
				nextPage = "contentList.dh";	//	리스트로
			}else {
				System.out.println("글 삭제 실패");
				response.setContentType("text/html;charset=utf-8");
				PrintWriter out = response.getWriter();
				out.print("<script>");
				out.print("alert('글 삭제 실패');");
				out.print("history.go(-1);");
				out.print("<script>");
			}
		}
		
		if(cmd.equals("contentIMGDown.dh")) {
			System.out.println("파일 다운로드 요청");
			service.imgDown(request, response);
		}
		
		if(cmd.equals("getWriting.dh")) {
			System.out.println("회원정보 페이지 게시글 목록 요청");
			json = gson.toJson(service.getWritingList(request));
			response.setContentType("application/json;charset=utf-8");
			response.getWriter().print(json);
		}
		
		if(cmd.equals("getLikeContent.dh")) {
			System.out.println("회원정보 페이지 좋아요 목록 요청");
			json = gson.toJson(service.getLikeContentList(request));
			response.setContentType("application/json;charset=utf-8");
			response.getWriter().print(json);
		}
		
		
		if(nextPage != null) {
			request.getRequestDispatcher(nextPage).forward(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
