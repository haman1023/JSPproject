package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import service.LikeContentService;
import service.LikeContentServiceImpl;

@WebServlet("*.like")
public class LikeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	LikeContentService service = new LikeContentServiceImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");
		
		String cmd = request.getRequestURI().substring(request.getContextPath().length()+1);
		
		Gson gson = new Gson();
		
		String json = "";
		
		if(cmd.equals("likeClick.like")) {
			System.out.println("좋아요 클릭!!!");
			service.clickLike(request);
			json = gson.toJson(null);
		}
		
		if(cmd.equals("likeList.like")) {
			System.out.println("좋아요 정보 불러오기!!");
			json = gson.toJson(service.getLike(request));
		}
		
		response.setContentType("application/json;charset=utf-8");
		response.getWriter().print(json);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
