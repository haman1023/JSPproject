package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.MemberService;
import service.MemberServiceImpl;
import vo.MemberVO;

@WebServlet("*.kk")
public class MemberController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	MemberService service = new MemberServiceImpl();
	

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("MemberController 요청");
		
		request.setCharacterEncoding("UTF-8");
		
		//MemberServiceImpl.loginCheck(request);
		
		String requestPath = request.getRequestURI();
		String contextPath = request.getContextPath();
		String command = requestPath.substring(contextPath.length());
		System.out.println(command+" 요청 드러옴!!!");
		
		String nextPage = "";

		if(command.equals("/main.kk")) {
			nextPage = "/common/main.jsp";
		}
		
		if(command.equals("/join.kk")) {
			nextPage = "/member/join.jsp";
		}
		
		if(command.equals("/memberJoin.kk")) {
			System.out.println("회원가입 처리 요청");
			
			response.setContentType("text/html;charset=utf-8");
			PrintWriter out = response.getWriter();
			
			if(service.memberJoin(request, response)) {
				out.print("<script>");
				out.print("alert('회원가입을 축하드립니다.');"); 
				out.print("location.href='login.kk';");
				out.print("</script>");
			}else{
				out.print("<script>");
				out.print("alert('회원가입에 실패했습니다.');"); 
				out.print("history.go(-1);");
				out.print("</script>");
			}
		}
		
		if(command.equals("/login.kk")) {
			nextPage="/member/login.jsp";
		}
		
		if(command.equals("/memberLogin.kk")) {
			System.out.println("로그인 처리 요청");
			if(service.memberLogin(request,response)) {
				System.out.println("로그인 성공");
				String path = contextPath+"/contentList.dh";
				System.out.println(path);
				response.sendRedirect(path);
				System.out.println("기근쌤 테스트");
			}else {
				System.out.println("로그인 실패");
				response.setContentType("text/html;charset=utf-8");
				PrintWriter out = response.getWriter();
				out.print("<script>");
				out.print("alert('로그인 실패');"); 
				out.print("history.go(-1);");
				out.print("</script>");
			}
		}
		
		// 로그 아웃
		if(command.equals("/logOut.kk")) {
			request.setAttribute("test", "LogOut 완료");
			service.logOut(request,response);
			nextPage="/common/main.jsp";
		}
		
		// 아이디 찾기
		if(command.equals("/findId.kk")) {
			nextPage="/member/findId.jsp";
		}
		
		if(command.equals("/findIdSubmit.kk")) {
			System.out.println("아이디 메일 발송 요청");
			service.findIdSubmit(request,response);
		}
		
		// 비밀번호 찾기
		if(command.equals("/findPass.kk")) {
			nextPage="/member/findPass.jsp";
		}
		
		if(command.equals("/findPassSubmit.kk")) {
			System.out.println("비밀번호 변경 메일 발송 요청");
			service.findPassSubmit(request,response);
		}
		//????
		if(command.equals("/passAccept.kk")) {
			service.checkPassCode(request,response);
		}
		
		if(command.equals("/changePass.kk")) {
			System.out.println("비밀번호 변경 요청");
			service.changePassCode(request,response);
		}
		
		if(command.equals("/memberInfo.kk")) {
			System.out.println("회원정보 페이지 요청");
			service.memberInfo(request);
			nextPage = "/member/info.jsp";
		}
		
		if(command.equals("/withdraw.kk")) {
			System.out.println("회원탈퇴 비밀번호 입력창 요청");
			// 비밀번호 재입력 요청
			nextPage="/member/withdraw.jsp";
		}
		
		if(command.equals("/withdrawSubmit.kk")) {
			System.out.println("회원탈퇴 요청");
			service.withdrawSubmit(request,response);
		}
		
		if(command.equals("/update.kk")) {
			System.out.println("회원 프로필 수정 페이지 요청");
			service.memberInfo(request);
			nextPage="/member/update.jsp";
		}
		
		if(command.equals("/memberUpdateSubmit.kk")) {
			System.out.println("회원 프로필 수정 요청");
			boolean isSuccess = service.memberUpdate(request);
			
			if(isSuccess) {
				System.out.println("프로필 수정 완료");
				response.sendRedirect("memberInfo.kk?m_id="+request.getAttribute("m_id"));
			}else {
				System.out.println("프로필 수정 실패");
				response.setContentType("text/html;charset=utf-8");
				PrintWriter out = response.getWriter();
				out.print("<script>");
				out.print("alert('글 작성 실패');"); 
				out.print("history.go(-1);");
				out.print("</script>");
			}
		}
		
		if(nextPage != null && !nextPage.equals("")) {
			RequestDispatcher rd 
				= request.getRequestDispatcher(nextPage);
			rd.forward(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
