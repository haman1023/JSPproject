package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import service.FollowService;
import service.FollowServiceImpl;

@WebServlet("*.fl")
public class FollowController extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	FollowService service = new FollowServiceImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");
		
		String cmd = request.getRequestURI().substring(request.getContextPath().length()+1);
		
		Gson gson = new Gson();
		
		String json = "";
		
		if(cmd.equals("followClick.fl")) {
			System.out.println("팔로우 클릭!!!");
			service.followClick(request);
			json = gson.toJson(null);
		}
		
		if(cmd.equals("isFollow.fl")) {
			System.out.println("팔로우 상태 확인!!!");
			json = gson.toJson(service.isFollow(request));
		}
		
		if(cmd.equals("getFollowList.fl")) {
			System.out.println("팔로우 목록 불러오기!!!");
			json = gson.toJson(service.getFollowList(request));
		}
		
		response.setContentType("application/json;charset=utf-8");
		response.getWriter().print(json);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
