package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import service.DirectMessageService;
import service.DirectMessageServiceImpl;

@WebServlet("*.dm")
public class DirectMessageController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	DirectMessageService service = new DirectMessageServiceImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");
		
		String cmd = request.getRequestURI().substring(request.getContextPath().length()+1);
		
		String nextPage = null;
		Gson gson = new Gson();
		String json = "";
		
		if(cmd.equals("dmList.dm")) {
			System.out.println("DM 리스트 요청");
			service.getDMList(request);
			nextPage = "/directmessage/dm_list.jsp";
		}
		
		if(cmd.equals("dmPage.dm")) {
			System.out.println("DM 페이지 요청");
			nextPage = "/directmessage/dm_page.jsp";
		}
		
		if(cmd.equals("getDirectMessage.dm")) {
			System.out.println("DM 메세지 요청");
			json = gson.toJson(service.getDirectMessage(request));
			response.setContentType("application/json;charset=utf-8");
			response.getWriter().print(json);
		}
		
		if(cmd.equals("sendDirectMessage.dm")) {
			System.out.println("DM 메세지 보내기");
			json = gson.toJson(service.sendDirectMessage(request));
			response.setContentType("application/json;charset=utf-8");
			response.getWriter().print(json);
		}
		
		if(nextPage != null) {
			request.getRequestDispatcher(nextPage).forward(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
