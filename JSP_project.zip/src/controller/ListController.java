package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import service.ListService;
import service.ListServiceImpl;

@WebServlet("*.jh")
public class ListController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	ListService ls = new ListServiceImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");
		
		String cmd = request.getRequestURI().substring(request.getContextPath().length()+1);
		Gson gson = new Gson();
		
		String json = "";
		
		if(cmd.contentEquals("contentList.jh")) {
			System.out.println("contentList.jh");
			json = gson.toJson(ls.contentlist(request));

		}
		
		if(cmd.contentEquals("contentSearch.jh")) {
			System.out.println("검색요청");
			json = gson.toJson(ls.search(request));
		}
		
		if(cmd.contentEquals("getSearchNick.jh")) {
			System.out.println("검색어 아이디 요청");
			json = gson.toJson(ls.getSearchNick(request));
		}
		
		response.setContentType("application/json;charset=utf-8");
		response.getWriter().print(json);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
