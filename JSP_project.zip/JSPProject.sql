USE JSPProject;

CREATE TABLE member(	--	회원 테이블
	m_id VARCHAR(15) primary key,		--	회원 아이디
	m_pass VARCHAR(15) NOT NULL,		--	비밀번호
	m_nick VARCHAR(10) NOT NULL UNIQUE,	--	닉네임
	m_email VARCHAR(30) NOT NULL,		--	이메일
	m_birth VARCHAR(8) NOT NULL,		--	생년월일
	m_gender CHAR(1) NOT NULL,			--	성별
	m_date TIMESTAMP default now()		--	가입일
);

CREATE TABLE content(	--	게시글
	c_num int primary key auto_increment,	--	글 번호
	c_writer_id VARCHAR(15),				--	글 작성자 아이디
	c_nick VARCHAR(10),						--	작성자 닉네임
	c_content TEXT NOT NULL,				--	글 내용
	c_img VARCHAR(20),						--	첨부 사진
	FOREIGN KEY (c_writer_id) REFERENCES member(m_id)
);

CREATE TABLE follow(	--	팔로우
	following_id VARCHAR(15),	--	팔로우 한 사람
	follower_id VARCHAR(15)		--	팔로우 당한 사람
);



CREATE TABLE like_content(	--	좋아요
	lc_num int,					--	좋아요 한 게시물 번호
	lc_id VARCHAR(15)			-- 	좋아요 한 사람
);

CREATE TABLE search_content(	--	검색어
	sc_content VARCHAR(30),			--	검색어
	sc_birth VARCHAR(6),			--	검색한 사람 생년월일
	sc_gender VARCHAR(1),			--	검색한 사람 성별
	sc_date TIMESTAMP default now()	--	검색한 날짜
);

CREATE TABLE test_code(			--	비밀번호 찾기용 테이블
	m_email VARCHAR(30),			--	이메일 주소
	code int 						--	임시 코드
);

DESC content;

ALTER TABLE comment ADD com_writer_file VARCHAR(20);

SHOW TABLES;

INSERT INTO member VALUES('haman', '12', '하만', 'shoozi@naver.com', '830925', 'M', now());

UPDATE member SET m_pass='12345678' WHERE m_id='haman';

SELECT * FROM member;

commit;

SELECT * FROM content;

SELECT * FROM comment;

ALTER TABLE content MODIFY c_img TEXT;

SELECT * FROM like_content;


SELECT * FROM follow;

-- 팔로우 한사람  최신 게시물 시간순서로 정렬
SELECT * FROM content WHERE c_writer_id='haman1023' OR c_writer_id 
in (SELECT follower_id FROM follow WHERE following_id = 'haman1023')
ORDER BY c_date DESC limit 0, 5;

-- 좋아요 한 최신 게시물 시간 순서로 정렬
SELECT * FROM content WHERE c_num
in (SELECT lc_num FROM like_content WHERE lc_id = 'haman1023')
ORDER BY c_date DESC;

-- 팔로우 한 회원 목록 불러오기
SELECT * FROM member WHERE m_id
in (SELECT follower_id FROM follow WHERE following_id='haman1023');

